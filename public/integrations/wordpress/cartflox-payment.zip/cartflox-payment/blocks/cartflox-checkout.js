( function () {
    'use strict';

    var registerPaymentMethod = window.wc.wcBlocksRegistry.registerPaymentMethod;
    var createElement         = window.wp.element.createElement;
    var decodeEntities        = window.wp.htmlEntities.decodeEntities;
    var getSetting            = window.wc.wcSettings.getSetting;

    var settings = getSetting( 'cartflox_data', {} );
    var title    = decodeEntities( settings.title || 'Mobile Money et carte bancaire' );
    var desc     = decodeEntities( settings.description || 'Payez avec Orange Money, Wave, MTN MoMo, Moov Money ou votre carte bancaire.' );

    var Content = function () {
        return createElement( 'span', null, desc );
    };

    var Label = function ( props ) {
        var PaymentMethodLabel = props.components.PaymentMethodLabel;
        var enfants = [ createElement( PaymentMethodLabel, { key: 'l', text: title } ) ];
        if ( settings.icon ) {
            enfants.push( createElement( 'img', { key: 'i', src: settings.icon, alt: '', style: { height: '24px', marginLeft: '8px' } } ) );
        }
        return createElement( 'span', { style: { display: 'inline-flex', alignItems: 'center' } }, enfants );
    };

    registerPaymentMethod( {
        name: 'cartflox',
        label: createElement( Label, null ),
        content: createElement( Content, null ),
        edit: createElement( Content, null ),
        canMakePayment: function () {
            return true;
        },
        ariaLabel: title,
        supports: {
            features: settings.supports || [ 'products' ],
        },
    } );
} )();
