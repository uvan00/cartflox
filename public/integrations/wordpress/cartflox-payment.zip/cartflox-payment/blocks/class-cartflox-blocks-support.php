<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * Prise en charge du checkout en blocs (WooCommerce Blocks) : sans cette
 * classe, Cartflox n'apparait pas sur les boutiques qui utilisent le nouveau
 * tunnel de commande.
 */
final class WC_Cartflox_Blocks_Support extends AbstractPaymentMethodType {

    protected $name = 'cartflox';

    public function initialize() {
        $this->settings = get_option( 'woocommerce_cartflox_settings', array() );
    }

    public function is_active() {
        return ! empty( $this->settings['enabled'] ) && 'yes' === $this->settings['enabled'];
    }

    public function get_payment_method_script_handles() {
        wp_register_script(
            'cartflox-blocks-integration',
            plugin_dir_url( __DIR__ ) . 'blocks/cartflox-checkout.js',
            array(
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
            ),
            CARTFLOX_WC_VERSION,
            true
        );
        return array( 'cartflox-blocks-integration' );
    }

    public function get_payment_method_data() {
        return array(
            'title'       => $this->get_setting( 'title' ),
            'description' => $this->get_setting( 'description' ),
            'icon'        => plugin_dir_url( __DIR__ ) . 'payment-icons.svg',
            'supports'    => array( 'products' ),
        );
    }
}
