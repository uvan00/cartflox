<?php
/*
Plugin Name: Cartflox pour WooCommerce
Plugin URI: https://cartflox.com/integration
Description: Encaissez par Orange Money, Wave, MTN MoMo, Moov Money et carte bancaire sur votre boutique WooCommerce, avec vos propres comptes agrégateurs, via Cartflox.
Version: 3.0.0
Author: Cartflox
Author URI: https://cartflox.com
License: GPL-2.0+
Text Domain: cartflox-payment
Requires at least: 6.0
Requires PHP: 7.4
WC requires at least: 7.0
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'CARTFLOX_WC_VERSION', '3.0.0' );
if ( ! defined( 'CARTFLOX_API_BASE' ) ) {
    define( 'CARTFLOX_API_BASE', 'https://cartflox.com/api' );
}

add_action( 'before_woocommerce_init', 'cartflox_declare_compat' );
function cartflox_declare_compat() {
    if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
    }
}

add_action( 'wp_enqueue_scripts', 'cartflox_enqueue_styles' );
function cartflox_enqueue_styles() {
    if ( function_exists( 'is_checkout' ) && ( is_checkout() || is_cart() ) ) {
        wp_enqueue_style( 'cartflox-checkout', plugins_url( 'assets/css/style.css', __FILE__ ), array(), CARTFLOX_WC_VERSION );
    }
}

add_filter( 'woocommerce_payment_gateways', 'cartflox_add_gateway' );
function cartflox_add_gateway( $gateways ) {
    $gateways[] = 'WC_Gateway_Cartflox';
    return $gateways;
}

add_action( 'plugins_loaded', 'cartflox_init_gateway' );
function cartflox_init_gateway() {
    if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
        return;
    }

    class WC_Gateway_Cartflox extends WC_Payment_Gateway {

        public function __construct() {
            $this->id                 = 'cartflox';
            $this->has_fields         = false;
            $this->method_title       = 'Cartflox';
            $this->method_description = 'Orange Money, Wave, MTN MoMo, Moov Money et carte bancaire, encaissés sur vos propres comptes agrégateurs. '
                . 'Adresse de webhook de cette boutique : <code>' . esc_html( $this->url_webhook() ) . '</code> (enregistrée automatiquement dans Cartflox à la sauvegarde).';
            $this->supports           = array( 'products' );
            $this->icon               = plugins_url( 'payment-icons.svg', __FILE__ );

            $this->init_form_fields();
            $this->init_settings();

            $this->title       = $this->get_option( 'title' );
            $this->description = $this->get_option( 'description' );
            $this->enabled     = $this->get_option( 'enabled' );

            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'enregistrer_webhook' ), 20 );
            add_action( 'woocommerce_api_cartflox', array( $this, 'recevoir_webhook' ) );
            add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'verifier_au_retour' ) );
            add_filter( 'woocommerce_gateway_icon', array( $this, 'icone_html' ), 10, 2 );
        }

        /* ------------------------------------------------------------ réglages */

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => 'Activer',
                    'label'   => 'Proposer Cartflox au paiement',
                    'type'    => 'checkbox',
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => 'Titre',
                    'type'        => 'text',
                    'description' => 'Ce que voit le client au moment de choisir son moyen de paiement.',
                    'default'     => 'Mobile Money et carte bancaire',
                    'desc_tip'    => true,
                ),
                'description' => array(
                    'title'   => 'Description',
                    'type'    => 'textarea',
                    'default' => 'Payez avec Orange Money, Wave, MTN MoMo, Moov Money ou votre carte bancaire.',
                ),
                'secret_key' => array(
                    'title'       => 'Clé secrète Cartflox',
                    'type'        => 'password',
                    'description' => 'Commence par af_live_sec_. Disponible dans votre tableau de bord Cartflox, rubrique API &amp; Logs.',
                    'default'     => '',
                ),
                'auto_webhook' => array(
                    'title'       => 'Webhook',
                    'label'       => 'Enregistrer automatiquement l\'adresse de webhook de cette boutique dans Cartflox (recommandé)',
                    'type'        => 'checkbox',
                    'description' => 'Sans webhook, les commandes ne passent en « payée » qu\'au retour du client sur la boutique.',
                    'default'     => 'yes',
                ),
            );
        }

        private function cle_secrete() {
            return trim( (string) $this->get_option( 'secret_key' ) );
        }

        private function url_webhook() {
            return home_url( '/?wc-api=cartflox' );
        }

        public function icone_html( $icon, $gateway_id ) {
            if ( $gateway_id !== $this->id ) {
                return $icon;
            }
            $src = plugins_url( 'payment-icons.svg', __FILE__ );
            return '<img src="' . esc_url( $src ) . '" alt="Orange Money, Wave, MTN MoMo, Moov Money, carte bancaire" style="height:32px;max-height:32px;width:auto;display:inline-block;vertical-align:middle;margin-left:8px;" />';
        }

        /**
         * A la sauvegarde des reglages : on declare l'adresse de webhook de la
         * boutique dans Cartflox, pour que les commandes passent en « payée »
         * sans que le client ait besoin de revenir sur le site.
         */
        public function enregistrer_webhook() {
            if ( 'yes' !== $this->get_option( 'auto_webhook' ) || '' === $this->cle_secrete() ) {
                return;
            }
            $url = $this->url_webhook();
            if ( 0 !== strpos( $url, 'https://' ) ) {
                WC_Admin_Settings::add_error( 'Cartflox : votre boutique doit être en HTTPS pour recevoir les webhooks (' . esc_html( $url ) . '). Les commandes seront confirmées au retour du client.' );
                return;
            }
            $r = $this->appel_api( 'PATCH', '/v1/config/webhook', array( 'webhookUrl' => $url ) );
            if ( $r['ok'] ) {
                WC_Admin_Settings::add_message( 'Cartflox : webhook enregistré (' . esc_html( $url ) . ').' );
            } else {
                WC_Admin_Settings::add_error( 'Cartflox : impossible d\'enregistrer le webhook. ' . esc_html( $r['message'] ) );
            }
        }

        /* ------------------------------------------------------------ paiement */

        public function process_payment( $order_id ) {
            $order = wc_get_order( $order_id );
            if ( '' === $this->cle_secrete() ) {
                throw new Exception( 'Clé API Cartflox manquante : WooCommerce > Réglages > Paiements > Cartflox.' );
            }

            $donnees = array(
                'amount'         => $this->montant_entier( $order->get_total() ),
                'currency'       => $order->get_currency(),
                'customer_name'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
                'customer_email' => $order->get_billing_email(),
                'customer_phone' => $order->get_billing_phone(),
                'description'    => sprintf( 'Commande #%s, %s', $order->get_order_number(), get_bloginfo( 'name' ) ),
                'success_url'    => $this->get_return_url( $order ),
                'cancel_url'     => $order->get_checkout_payment_url(),
                'metadata'       => array(
                    'order_id'  => (string) $order->get_id(),
                    'order_key' => $order->get_order_key(),
                    'source'    => 'woocommerce',
                ),
            );

            $r = $this->appel_api( 'POST', '/v1/checkout/sessions', $donnees );
            if ( ! $r['ok'] || empty( $r['body']['url'] ) ) {
                $this->journal( 'création de session refusée pour la commande #' . $order->get_id() . ' : ' . $r['message'] );
                throw new Exception( 'Cartflox : ' . $r['message'] );
            }

            $session = $r['body'];
            $sessions = (array) $order->get_meta( '_cartflox_sessions' );
            $sessions[] = $session['id'];
            $order->update_meta_data( '_cartflox_sessions', array_values( array_unique( $sessions ) ) );
            $order->update_meta_data( '_cartflox_session_id', $session['id'] );
            $order->update_status( 'pending', 'En attente du paiement Cartflox (session ' . $session['id'] . ').' );
            $order->save();

            if ( isset( WC()->cart ) ) {
                WC()->cart->empty_cart();
            }

            return array(
                'result'   => 'success',
                'redirect' => $session['url'],
            );
        }

        /**
         * Webhook signe envoye par Cartflox a chaque changement de statut.
         * On verifie la signature HMAC-SHA256 avec la cle secrete avant de
         * toucher a la commande : sans cela, n'importe qui pourrait « payer ».
         */
        public function recevoir_webhook() {
            $brut  = file_get_contents( 'php://input' );
            $ts    = isset( $_SERVER['HTTP_X_AFRIFLOW_TIMESTAMP'] ) ? trim( (string) wp_unslash( $_SERVER['HTTP_X_AFRIFLOW_TIMESTAMP'] ) ) : '';
            $ent   = isset( $_SERVER['HTTP_X_AFRIFLOW_SIGNATURE'] ) ? trim( (string) wp_unslash( $_SERVER['HTTP_X_AFRIFLOW_SIGNATURE'] ) ) : '';
            $sig   = '';
            foreach ( explode( ',', $ent ) as $partie ) {
                if ( 0 === strpos( $partie, 'v1=' ) ) {
                    $sig = substr( $partie, 3 );
                }
            }
            $cle     = $this->cle_secrete();
            $attendu = hash_hmac( 'sha256', $ts . '.' . $brut, $cle );

            if ( '' === $cle || '' === $ts || '' === $sig || abs( time() - (int) $ts ) > 300 || ! hash_equals( $attendu, $sig ) ) {
                $this->journal( 'webhook refusé : signature invalide ou trop ancienne' );
                status_header( 400 );
                echo 'signature invalide';
                exit;
            }

            $evt  = json_decode( $brut, true );
            $data = isset( $evt['data'] ) && is_array( $evt['data'] ) ? $evt['data'] : array();
            $order_id = isset( $data['metadata']['order_id'] ) ? absint( $data['metadata']['order_id'] ) : 0;
            $order    = $order_id ? wc_get_order( $order_id ) : false;

            if ( ! $order || $order->get_payment_method() !== $this->id ) {
                status_header( 200 );
                echo 'ignore';
                exit;
            }
            if ( empty( $data['metadata']['order_key'] ) || $data['metadata']['order_key'] !== $order->get_order_key() ) {
                status_header( 400 );
                echo 'commande inconnue';
                exit;
            }
            $sessions = (array) $order->get_meta( '_cartflox_sessions' );
            if ( ! empty( $data['id'] ) && ! empty( $sessions ) && ! in_array( $data['id'], $sessions, true ) ) {
                status_header( 400 );
                echo 'session inconnue pour cette commande';
                exit;
            }

            $this->appliquer_statut( $order, $data );
            status_header( 200 );
            echo 'ok';
            exit;
        }

        /**
         * Page de remerciement : si le webhook n'est pas encore arrive, on
         * demande le statut a Cartflox pour ne pas laisser le client devant une
         * commande « en attente » alors qu'il vient de payer.
         */
        public function verifier_au_retour( $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order || $order->is_paid() ) {
                return;
            }
            $session_id = $order->get_meta( '_cartflox_session_id' );
            if ( $session_id ) {
                $r = $this->appel_api( 'GET', '/v1/checkout/sessions/' . rawurlencode( $session_id ) . '/status' );
                if ( $r['ok'] && ! empty( $r['body']['status'] ) ) {
                    $this->appliquer_statut( $order, $r['body'] );
                }
            }
            if ( ! $order->is_paid() ) {
                wc_print_notice( 'Votre paiement est en cours de confirmation. Vous recevrez un e-mail dès qu\'il sera validé.', 'notice' );
            }
        }

        private function appliquer_statut( $order, $data ) {
            $statut = strtoupper( isset( $data['status'] ) ? (string) $data['status'] : '' );
            $ref    = ! empty( $data['provider_reference'] ) ? $data['provider_reference'] : ( isset( $data['id'] ) ? $data['id'] : '' );

            if ( 'SUCCESS' === $statut ) {
                if ( $order->is_paid() ) {
                    return; // deja traite : le meme webhook peut arriver deux fois
                }
                $attendu = $this->montant_entier( $order->get_total() );
                $recu    = isset( $data['amount'] ) ? (float) $data['amount'] : 0;
                $devise  = isset( $data['currency'] ) ? strtoupper( (string) $data['currency'] ) : '';
                if ( abs( $recu - $attendu ) > 0.5 || ( '' !== $devise && $devise !== strtoupper( $order->get_currency() ) ) ) {
                    $order->update_status( 'on-hold', sprintf( 'Cartflox : montant reçu %s %s différent du total attendu %s %s. À vérifier avant de livrer.', $recu, $devise, $attendu, $order->get_currency() ) );
                    return;
                }
                $order->payment_complete( $ref );
                $fournisseur = ! empty( $data['provider'] ) ? $data['provider'] : 'Cartflox';
                $order->add_order_note( sprintf( 'Paiement confirmé par Cartflox via %s (réf. %s).', $fournisseur, $ref ) );
            } elseif ( 'FAILED' === $statut ) {
                if ( $order->has_status( 'pending' ) ) {
                    $order->update_status( 'failed', 'Paiement Cartflox échoué ou refusé par l\'opérateur. Le client peut réessayer.' );
                }
            } elseif ( 'CANCELLED' === $statut ) {
                if ( $order->has_status( 'pending' ) ) {
                    $order->update_status( 'cancelled', 'Paiement Cartflox annulé.' );
                }
            } elseif ( 'REFUNDED' === $statut ) {
                $order->add_order_note( 'Cartflox : paiement remboursé depuis le tableau de bord Cartflox.' );
            }
        }

        /* ------------------------------------------------------------ outils */

        /**
         * Cartflox attend un montant entier (5000 = 5 000 XOF). Les devises a
         * decimales sont arrondies a l'unite.
         */
        private function montant_entier( $total ) {
            return (int) round( (float) $total );
        }

        private function appel_api( $methode, $chemin, $corps = null, $entetes = array() ) {
            $args = array(
                'method'  => $methode,
                'timeout' => 45,
                'headers' => array_merge( array(
                    'Authorization' => 'Bearer ' . $this->cle_secrete(),
                    'Content-Type'  => 'application/json',
                    'Accept'        => 'application/json',
                    'User-Agent'    => 'Cartflox-WooCommerce/' . CARTFLOX_WC_VERSION . ' (' . home_url() . ')',
                ), $entetes ),
            );
            if ( null !== $corps ) {
                $args['body'] = wp_json_encode( $corps );
            }
            $reponse = wp_remote_request( CARTFLOX_API_BASE . $chemin, $args );
            if ( is_wp_error( $reponse ) ) {
                return array( 'ok' => false, 'code' => 0, 'body' => array(), 'message' => 'connexion impossible (' . $reponse->get_error_message() . ')' );
            }
            $code = (int) wp_remote_retrieve_response_code( $reponse );
            $body = json_decode( wp_remote_retrieve_body( $reponse ), true );
            if ( ! is_array( $body ) ) {
                $body = array();
            }
            $ok = $code >= 200 && $code < 300;
            $message = $ok ? '' : ( ! empty( $body['error'] ) ? $body['error'] : ( ! empty( $body['message'] ) ? $body['message'] : 'erreur HTTP ' . $code ) );
            if ( 401 === $code ) {
                $message = 'clé API refusée. Vérifiez la clé secrète (af_live_sec_...) dans les réglages.';
            }
            return array( 'ok' => $ok, 'code' => $code, 'body' => $body, 'message' => $message );
        }

        private function journal( $message ) {
            if ( function_exists( 'wc_get_logger' ) ) {
                wc_get_logger()->info( $message, array( 'source' => 'cartflox' ) );
            }
        }
    }
}

add_action( 'woocommerce_blocks_loaded', 'cartflox_blocks_support' );
function cartflox_blocks_support() {
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }
    require_once __DIR__ . '/blocks/class-cartflox-blocks-support.php';
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function ( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $registry ) {
            $registry->register( new WC_Cartflox_Blocks_Support() );
        }
    );
}
