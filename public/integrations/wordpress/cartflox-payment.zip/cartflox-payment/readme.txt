=== Cartflox pour WooCommerce ===
Contributors: cartflox
Tags: mobile money, orange money, wave, mtn momo, moov, paiement, afrique, woocommerce
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 3.0.0
License: GPLv2 or later

Encaissez par Orange Money, Wave, MTN MoMo, Moov Money et carte bancaire sur WooCommerce, avec vos propres comptes agrégateurs.

== Description ==

Cartflox ajoute un moyen de paiement à votre boutique WooCommerce. Au moment de payer, le client est envoyé sur la page de paiement Cartflox (choix de l'opérateur, code OTP, redirection Wave, carte bancaire), puis revient sur votre boutique. La commande passe automatiquement en « payée » grâce au webhook signé, ou au retour du client si le webhook n'est pas encore arrivé.

Votre argent ne transite jamais par Cartflox : vous branchez vos propres clés d'agrégateurs (PayDunya, CinetPay, PawaPay, Stripe, Paystack, Flutterwave, FedaPay...) dans votre tableau de bord Cartflox.

== Installation ==

1. Dans WordPress : Extensions > Ajouter > Téléverser une extension, choisissez cartflox-payment.zip, puis Activer.
2. WooCommerce > Réglages > Paiements > Cartflox > Gérer.
3. Collez votre clé secrète (af_live_sec_...) trouvée dans votre tableau de bord Cartflox, rubrique API & Logs.
4. Enregistrez : le plugin déclare lui-même l'adresse de webhook de votre boutique dans Cartflox.

Votre boutique doit être en HTTPS pour recevoir les webhooks.

== Changelog ==

= 3.0.0 =
* Passage sur cartflox.com, authentification par en-tête Authorization.
* Webhook signé HMAC-SHA256 : la commande passe en « payée » sans action du client.
* Vérification du statut au retour du client (rattrapage si le webhook est en retard).
* Contrôle du montant et de la devise avant de valider une commande.
* Enregistrement automatique de l'adresse de webhook.
* Compatible checkout en blocs et stockage HPOS.
